package com.example.lycle;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Fragment_lycle#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Fragment_lycle extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Fragment_lycle() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Fragment_lycle.
     */
    // TODO: Rename and change types and number of parameters
    public static Fragment_lycle newInstance(String param1, String param2) {
        Fragment_lycle fragment = new Fragment_lycle();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = (ViewGroup) inflater.inflate(R.layout.fragment_lycle, container, false);
        Button start=view.findViewById(R.id.start);
        Button start2=view.findViewById(R.id.start2);
        Button other=view.findViewById(R.id.other);
        LinearLayout call=view.findViewById(R.id.call);
        TextView today_lycle=view.findViewById(R.id.today_lycle);

        String[] str =  {"걷기", "근력운동", "스트레칭", "손협응 운동", "두뇌운동", "발건강 운동"};
        String[] url = {"BfT37Ym-bBY","BfT37Ym-bBY","BfT37Ym-bBY","BfT37Ym-bBY","BfT37Ym-bBY","BfT37Ym-bBY"};
        int r = (int)(Math.random()*6);
        today_lycle.setText(str[r]);

        ImageView image=view.findViewById(R.id.img);

        String imageStr = "https://img.youtube.com/vi/"+url[r]+"/mqdefault.jpg";
        Glide.with(view).load(imageStr).into(image);

        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://youtu.be/"+url[r]));
                startActivity(intent);
            }
        });

        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:1899-9988"));
                startActivity(intent);
            }
        });

        start2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), SelfCheck.class);
                startActivity(intent);
            }
        });

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (r+1) {
                    case 1:
                        SharedPreferencesManager.set_WHAT_EXER_CHOICE(v.getContext(), "exer", 1);
                        break;
                    case 2:
                        SharedPreferencesManager.set_WHAT_EXER_CHOICE(v.getContext(), "exer", 2);
                        break;
                    case 3:
                        SharedPreferencesManager.set_WHAT_EXER_CHOICE(v.getContext(), "exer", 3);
                        break;
                    case 4:
                        SharedPreferencesManager.set_WHAT_EXER_CHOICE(v.getContext(), "exer", 4);
                        break;
                    case 5:
                        SharedPreferencesManager.set_WHAT_EXER_CHOICE(v.getContext(), "exer", 5);
                        break;
                    case 6:
                        SharedPreferencesManager.set_WHAT_EXER_CHOICE(v.getContext(), "exer", 6);
                        break;
                }
                Intent intent = new Intent(getContext(), Exer_LOADING.class);
                startActivity(intent);
            }
        });
        other.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), Lycle_list.class);
                startActivity(intent);
            }
        });



        return view;
    }
}