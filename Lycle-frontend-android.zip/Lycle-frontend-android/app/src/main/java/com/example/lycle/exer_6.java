package com.example.lycle;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class exer_6 extends AppCompatActivity {
    private TextView time;
    int h,s,m;
    String H,S,M;
    Button finish;
    Dialog dialog;
    Timer timer = new Timer();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exer_6);
        time = findViewById(R.id.time);
        finish=findViewById(R.id.finish);

        final Handler handler = new Handler(){
            public void handleMessage(Message msg){
                // 원래 하려던 동작 (UI변경 작업 등)
                if(h<10){
                    H="0"+Integer.toString(h);
                }
                else{
                    H=Integer.toString(h);
                }
                if(m<10){
                    M="0"+Integer.toString(m);
                }
                else{
                    M=Integer.toString(m);
                }
                if(s<10){
                    S="0"+Integer.toString(s);
                }
                else{
                    S=Integer.toString(s);
                }
                time.setText(H+":"+M+":"+S);
                if(m>=30){
                    finish.setVisibility(View.VISIBLE);

                }
            }
        };

        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                Message msg = handler.obtainMessage();
                handler.sendMessage(msg);
                if(s != 59) {
                    //1초씩 감소
                    s++;
                }
                if(s==59) {
                    s=0;
                    if(m!=59){m++;}
                    else{m=0; h++;}
                }
            }
        };
        //타이머를 실행
        timer.schedule(timerTask, 0, 1000); //Timer 실행

        dialog=new Dialog(exer_6.this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.alertdialog);
        ImageButton back=findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showdialog();
            }
        });

        WebView webView=findViewById(R.id.webview);
        webView.setWebViewClient(new WebViewClient());
        //자바스크립트 허용
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        webView.loadUrl("https://youtu.be/NuN_5_XzMxk");

    }
    public void showdialog(){
        dialog.show();
        Button yes=dialog.findViewById(R.id.yes);
        Button no=dialog.findViewById(R.id.no);
        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Lycle_list.class);
                startActivity(intent);
            }
        });
        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }
}