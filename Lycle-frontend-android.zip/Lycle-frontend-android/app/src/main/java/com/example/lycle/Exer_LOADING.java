package com.example.lycle;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class Exer_LOADING extends AppCompatActivity {
    private ProgressBar progressBarCircle;
    private TextView time;
    private TextView text;
    Button start, stop;
    int second=4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exer__l_o_a_d_i_n_g);
        int where = SharedPreferencesManager.get_WHAT_EXER_CHOICE(this,"exer");
        progressBarCircle = findViewById(R.id.progressBarCircle);
        text=findViewById(R.id.text);
        time = findViewById(R.id.timer);
        start=findViewById(R.id.start);
        stop=findViewById(R.id.stop);
        Timer timer = new Timer();
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timer.cancel();
                move_to_activity(where);
            }
        });
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
                timer.cancel();
            }
        });
        ImageButton back=findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
                timer.cancel();
            }
        });
        final Handler handler = new Handler(){
            public void handleMessage(Message msg){
                // 원래 하려던 동작 (UI변경 작업 등)
                time.setText(Integer.toString(second));
                progressBarCircle.setProgress(second*30);
                switch (second){
                    case 3:
                        text.setText("당뇨 질환이 있는 경우\n" +
                                "공복운동을 지양해주세요");
                        break;
                    case 2:
                        text.setText("나의 컨디션에 맞는 운동을 선택해주세요");
                        break;
                    case 1:
                        text.setText("오늘도 활기찬 30분 챌린지 시작해볼까요?");
                        break;
                }
            }
        };

        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                Message msg = handler.obtainMessage();
                handler.sendMessage(msg);
                if(second != 1) {
                    //1초씩 감소

                    second--;
                }
                if(second==1) {
                    timer.cancel();
                    move_to_activity(where);
                }
            }
        };
        //타이머를 실행
        timer.schedule(timerTask, 0, 1000); //Timer 실행
    }
    public void move_to_activity(int a){
        switch (a) {
            case 1:
                Intent intent = new Intent(getApplicationContext(), exer_1.class);
                startActivity(intent);
                break;
            case 2:
                Intent intent2 = new Intent(getApplicationContext(), exer_2.class);
                startActivity(intent2);
                break;
            case 3:
                Intent intent3 = new Intent(getApplicationContext(), exer_3.class);
                startActivity(intent3);
                break;
            case 4:
                Intent intent4 = new Intent(getApplicationContext(), exer_4.class);
                startActivity(intent4);
                break;
            case 5:
                Intent intent5 = new Intent(getApplicationContext(), exer_5.class);
                startActivity(intent5);
                break;
            case 6:
                Intent intent6 = new Intent(getApplicationContext(), exer_6.class);
                startActivity(intent6);
                break;
        }
    }

}

