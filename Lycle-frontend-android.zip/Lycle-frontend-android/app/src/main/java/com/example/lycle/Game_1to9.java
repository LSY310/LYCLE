package com.example.lycle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class Game_1to9 extends AppCompatActivity {
    TextView b1, b2, b3, b4, b5, b6, b7, b8, b9;
    public int number=1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_1to9);
        b1=findViewById(R.id.b1);
        b2=findViewById(R.id.b2);
        b3=findViewById(R.id.b3);
        b4=findViewById(R.id.b4);
        b5=findViewById(R.id.b5);
        b6=findViewById(R.id.b6);
        b7=findViewById(R.id.b7);
        b8=findViewById(R.id.b8);
        b9=findViewById(R.id.b9);

        int count = 9; // 난수 생성 갯수
        int a[] = new int[count];
        Random r = new Random();

        for(int i=0; i<count; i++){
            a[i] = r.nextInt(9) + 1;
            for(int j=0; j<i; j++){
                if(a[i] == a[j]){
                    i--;
                }
            }
        }

        b1.setText(String.valueOf(a[0]));
        b2.setText(String.valueOf(a[1]));
        b3.setText(String.valueOf(a[2]));
        b4.setText(String.valueOf(a[3]));
        b5.setText(String.valueOf(a[4]));
        b6.setText(String.valueOf(a[5]));
        b7.setText(String.valueOf(a[6]));
        b8.setText(String.valueOf(a[7]));
        b9.setText(String.valueOf(a[8]));

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(number==a[0]){
                    number++;
                    Toast.makeText(getApplicationContext(), "next", Toast.LENGTH_SHORT).show();
                }
                else{Toast.makeText(getApplicationContext(), "땡", Toast.LENGTH_SHORT).show();
                }}
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(number==a[1]){
                    number++;
                    Toast.makeText(getApplicationContext(), "next", Toast.LENGTH_SHORT).show();
                }
                else{Toast.makeText(getApplicationContext(), "땡", Toast.LENGTH_SHORT).show();
                }}
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(number==a[2]){
                    number++;
                    Toast.makeText(getApplicationContext(), "next", Toast.LENGTH_SHORT).show();
                }
                else{Toast.makeText(getApplicationContext(), "땡", Toast.LENGTH_SHORT).show();
                }}
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(number==a[3]){
                    number++;
                    Toast.makeText(getApplicationContext(), "next", Toast.LENGTH_SHORT).show();
                }
                else{Toast.makeText(getApplicationContext(), "땡", Toast.LENGTH_SHORT).show();
                }}
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(number==a[4]){
                    number++;
                    Toast.makeText(getApplicationContext(), "next", Toast.LENGTH_SHORT).show();
                }
                else{Toast.makeText(getApplicationContext(), "땡", Toast.LENGTH_SHORT).show();
                }}
        });
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(number==a[5]){
                    number++;
                    Toast.makeText(getApplicationContext(), "next", Toast.LENGTH_SHORT).show();
                }
                else{Toast.makeText(getApplicationContext(), "땡", Toast.LENGTH_SHORT).show();
                }}
        });
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(number==a[6]){
                    number++;
                    Toast.makeText(getApplicationContext(), "next", Toast.LENGTH_SHORT).show();
                }
                else{Toast.makeText(getApplicationContext(), "땡", Toast.LENGTH_SHORT).show();
                }}
        });
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(number==a[7]){
                    number++;
                    Toast.makeText(getApplicationContext(), "next", Toast.LENGTH_SHORT).show();
                }
                else{Toast.makeText(getApplicationContext(), "땡", Toast.LENGTH_SHORT).show();
                }}
        }); b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(number==a[8]){
                    number++;
                    Toast.makeText(getApplicationContext(), "꿑", Toast.LENGTH_SHORT).show();
                }
                else{Toast.makeText(getApplicationContext(), "땡", Toast.LENGTH_SHORT).show();
                }}
        });

    }
}