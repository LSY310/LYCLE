package com.example.lycle;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class Lycle_list extends AppCompatActivity {
    Button b1,b2,b3,b4,b5,b6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lycle_list);

        ImageButton back=findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),BottomNavigationActivity.class);
                startActivity(intent);
            }
        });

        b1=findViewById(R.id.b1);
        b2=findViewById(R.id.b2);
        b3=findViewById(R.id.b3);
        b4=findViewById(R.id.b4);
        b5=findViewById(R.id.b5);
        b6=findViewById(R.id.b6);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferencesManager.set_WHAT_EXER_CHOICE(v.getContext(), "exer", 1);
                Intent intent = new Intent(getApplicationContext(),Exer_LOADING.class);
                startActivity(intent);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferencesManager.set_WHAT_EXER_CHOICE(v.getContext(), "exer", 2);
                Intent intent = new Intent(getApplicationContext(),Exer_LOADING.class);
                startActivity(intent);
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferencesManager.set_WHAT_EXER_CHOICE(v.getContext(), "exer", 3);
                Intent intent = new Intent(getApplicationContext(),Exer_LOADING.class);
                startActivity(intent);
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferencesManager.set_WHAT_EXER_CHOICE(v.getContext(), "exer", 4);
                Intent intent = new Intent(getApplicationContext(),Exer_LOADING.class);
                startActivity(intent);
            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferencesManager.set_WHAT_EXER_CHOICE(v.getContext(), "exer", 5);
                Intent intent = new Intent(getApplicationContext(),Exer_LOADING.class);
                startActivity(intent);
            }
        });
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferencesManager.set_WHAT_EXER_CHOICE(v.getContext(), "exer", 6);
                Intent intent = new Intent(getApplicationContext(),Exer_LOADING.class);
                startActivity(intent);
            }
        });



    }
}