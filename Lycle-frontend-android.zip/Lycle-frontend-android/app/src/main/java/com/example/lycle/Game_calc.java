package com.example.lycle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Game_calc extends AppCompatActivity {
    TextView text;
    EditText answer;
    int result=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_calc);

        text=findViewById(R.id.text);
        answer=findViewById(R.id.answer);
        makeQuiz();
    }
    public void makeQuiz() {
        int left = getRandom (8, 2);
        int right = getRandom (8, 2);
        text.setText(left + " * " + right + " = ?");
        result = left * right;
    }



    public int getRandom (int max, int offset) {
        int nResult = (int) (Math.random() * max) + offset;
        return nResult;
    }



    public void onBtnResult(View v) {
        String strAnswer = answer.getText().toString();
        int answer = Integer.parseInt(strAnswer);
        if( answer == result )
            Toast.makeText(this, result + " – Correct answer!", Toast.LENGTH_LONG).show();
        else
            Toast.makeText(this, "Wrong - " + result, Toast.LENGTH_LONG).show();
        makeQuiz();
    }

}