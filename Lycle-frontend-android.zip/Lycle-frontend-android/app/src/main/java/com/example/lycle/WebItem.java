package com.example.lycle;

public class WebItem {
    private String url;
    public WebItem(){

    };
    public void setUrl(String url){this.url=url;}
    public String getUrl(){return url;}
}
