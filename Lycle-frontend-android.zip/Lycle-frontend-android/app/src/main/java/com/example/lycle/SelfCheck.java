package com.example.lycle;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class SelfCheck extends AppCompatActivity {
    int c=0;
    int y=0;
    Dialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_self_check);

        ImageButton back=findViewById(R.id.back);
        Button check=findViewById(R.id.check);
        Button stop=findViewById(R.id.stop);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        dialog=new Dialog(SelfCheck.this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.selfcheck_dialog);

        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showdialog();
            }
        });

    }

    public void count_y(View view){
            view.setBackgroundColor(Color.parseColor("#59036C9D"));
            c++;
            y++;
            }
    public void count_n(View view){
            view.setBackgroundColor(Color.parseColor("#59036C9D"));
        }
    public void showdialog(){
        dialog.show();

        TextView score=dialog.findViewById(R.id.score);
        score.setText(Integer.toString(y));

        ImageView img=dialog.findViewById(R.id.img);
        if(y<5){
        img.setImageResource(R.drawable.self_1);}
        else if(y<11){
            img.setImageResource(R.drawable.self_2);
        }
        else if(y<15){
            img.setImageResource(R.drawable.self_3);
        }

        Button yes=dialog.findViewById(R.id.yes);
        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),BottomNavigationActivity.class);
                startActivity(intent);
            }
        });
    }

}