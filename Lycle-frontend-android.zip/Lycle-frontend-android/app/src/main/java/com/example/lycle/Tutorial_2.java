package com.example.lycle;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Tutorial_2#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Tutorial_2 extends Fragment {
    private static int page;
    private static String title;

    public Tutorial_2() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static Tutorial_2 newInstance(int page, String title) {
        Tutorial_2 fragment = new Tutorial_2();
        Bundle args = new Bundle();
        args.putInt("someInt", page);
        args.putString("someTitle", title);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            page = getArguments().getInt("someInt", 0);
            title = getArguments().getString("someTitle");
        }
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_tutorial_2, container, false);
    }
}