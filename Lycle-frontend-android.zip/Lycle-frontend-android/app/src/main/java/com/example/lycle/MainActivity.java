package com.example.lycle;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button login, join;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        login = (Button)findViewById(R.id.login);
        boolean sharedPreferences = SharedPreferencesManager.get_first_app_execute(this,"first");
        Log.d("lll", "sharedPreferences=>"+sharedPreferences);
        if (sharedPreferences==true) {
            //튜토리얼로 넘어가기
            startActivity(new Intent(this, TutorialActivity.class));
        }


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(v.getContext(), BottomNavigationActivity.class));
            }
        });
    }
}