package com.example.lycle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Challenge_complete extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_challenge_complete);
    }
}