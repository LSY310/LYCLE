package com.example.lycle;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

public class exer_1 extends AppCompatActivity implements SensorEventListener {
    Dialog dialog;
    SensorManager sensorManager;
    Sensor stepCountSensor;
    TextView stepCountView;
    boolean gps_enable = false;

    private LocationManager locationManager;
    private Location last = null;
    private Location now = null;

    TextView time, km, gps;
    int s, m, h;
    String S, M;
    Timer timer = new Timer();
    private ProgressBar walkcircle, kmcircle, timecircle, gpscircle;

    // 현재 걸음 수
    int currentSteps = 0;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exer_1);

        stepCountView = findViewById(R.id.walk);
        time = findViewById(R.id.time);
        gps = findViewById(R.id.gps);
        km = findViewById(R.id.km);

        walkcircle = findViewById(R.id.walkcircle);
        gpscircle = findViewById(R.id.gpscircle);
        kmcircle = findViewById(R.id.kmcircle);
        timecircle = findViewById(R.id.timecircle);

        final Handler handler = new Handler() {
            public void handleMessage(Message msg) {
                timecircle.setProgress(s);
                // 원래 하려던 동작 (UI변경 작업 등)
                if (m < 10) {
                    M = "0" + Integer.toString(m);
                } else {
                    M = Integer.toString(m);
                }
                if (s < 10) {
                    S = "0" + Integer.toString(s);
                } else {
                    S = Integer.toString(s);
                }
                time.setText(M + ":" + S);
            }
        };

        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                Message msg = handler.obtainMessage();
                handler.sendMessage(msg);
                if (s != 59) {
                    //1초씩 감소
                    s++;
                }
                if (s == 59) {
                    s = 0;
                    if (m != 59) {
                        m++;
                    } else {
                        m = 0;
                        h++;
                    }
                }
                if (m >= 30) {
                    timer.cancel();
                    Intent intent = new Intent(getApplicationContext(), Challenge_complete.class);
                    startActivity(intent);
                }
            }
        };

        //타이머를 실행
        timer.schedule(timerTask, 0, 1000); //Timer 실행


        // 활동 퍼미션 체크
        if(ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_DENIED){

            requestPermissions(new String[]{Manifest.permission.ACTIVITY_RECOGNITION}, 0);
        }

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        stepCountSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);


        // 디바이스에 걸음 센서의 존재 여부 체크
        if (stepCountSensor == null) {
            Toast.makeText(this, "No Step Sensor", Toast.LENGTH_SHORT).show();
        }

        //경고 다이얼로그
        dialog=new Dialog(exer_1.this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.alertdialog);
        ImageButton back=findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showdialog();
            }
        });
    }
    public void showdialog(){

        dialog.show();
        Button yes=dialog.findViewById(R.id.yes);
        Button no=dialog.findViewById(R.id.no);
        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timer.cancel();
                Intent intent = new Intent(getApplicationContext(),Lycle_list.class);
                startActivity(intent);
            }
        });
        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }

    public void onStart() {
        super.onStart();
        if(stepCountSensor !=null) {
            sensorManager.registerListener((SensorEventListener) this,stepCountSensor,SensorManager.SENSOR_DELAY_FASTEST);
        }
    }

    public void onSensorChanged(SensorEvent event) {
        // 걸음 센서 이벤트 발생시
        if(event.sensor.getType() == Sensor.TYPE_STEP_DETECTOR){

            if(event.values[0]==1.0f){
                // 센서 이벤트가 발생할때 마다 걸음수 증가
                currentSteps++;
                stepCountView.setText(String.valueOf(currentSteps));
            }
        }
    }

    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }





}