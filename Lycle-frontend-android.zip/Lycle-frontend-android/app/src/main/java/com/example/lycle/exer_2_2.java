package com.example.lycle;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.lang.reflect.Array;
import java.util.Timer;
import java.util.TimerTask;

import static android.content.ContentValues.TAG;

public class exer_2_2 extends AppCompatActivity {
    DBHelper dbHelper;
    ListView listView;
    private TextView time;
    int h,s,m;
    String H,S,M;
    Button finish;
    Dialog dialog;
    Timer timer = new Timer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exer_2_2);
        time = findViewById(R.id.time);
        finish=findViewById(R.id.finish);

        dialog=new Dialog(exer_2_2.this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.alertdialog);
        ImageButton back=findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showdialog();
            }
        });

        final Handler handler = new Handler(){
            public void handleMessage(Message msg){
                // 원래 하려던 동작 (UI변경 작업 등)
                if(h<10){
                    H="0"+Integer.toString(h);
                }
                else{
                    H=Integer.toString(h);
                }
                if(m<10){
                    M="0"+Integer.toString(m);
                }
                else{
                    M=Integer.toString(m);
                }
                if(s<10){
                    S="0"+Integer.toString(s);
                }
                else{
                    S=Integer.toString(s);
                }
                time.setText(H+":"+M+":"+S);
                if(s>=30){
                    finish.setVisibility(View.VISIBLE);

                }
            }
        };

        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                Message msg = handler.obtainMessage();
                handler.sendMessage(msg);
                if(s != 59) {
                    //1초씩 감소
                    s++;
                }
                if(s==59) {
                    s=0;
                    if(m!=59){m++;}
                    else{m=0; h++;}

                }


            }
        };
        //타이머를 실행
        timer.schedule(timerTask, 0, 1000); //Timer 실행

        dbHelper = new DBHelper(exer_2_2.this, 1);
        String all=dbHelper.getResult();
        Log.d(TAG,"test : "+all);
        String[] arr=all.split("<");
        listView = findViewById(R.id.list);
        webviewAdapter adapter=new webviewAdapter();
        int length = arr.length;
        for(int i=0; i<length; i++){
            adapter.addItemToList(arr[i]);
            Log.d(TAG,"test : "+arr[i]);
        }
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //SingerDTO dto = (SingerDTO) adapter.getItem(position)
                String item=String.valueOf(parent.getItemAtPosition(position));
                Log.d(TAG,"test : "+position);
                /*WebView webView = new WebView(getApplicationContext());
                setContentView(webView);
                webView.setWebViewClient(new WebViewClient());
                webView.loadUrl("https://youtu.be/"+arr[position]);*/
                Dialog dialog=new Dialog(exer_2_2.this);
                //dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setContentView(R.layout.webdialog);
                WebView webView=dialog.findViewById(R.id.webview);
                webView.setWebViewClient(new WebViewClient());
                //자바스크립트 허용
                webView.getSettings().setJavaScriptEnabled(true);

                webView.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
                webView.loadUrl("https://youtu.be/"+arr[position]);
                dialog.show();
                dialog.findViewById(R.id.ok).setOnClickListener(new View.OnClickListener(){
                    public void onClick(View view){
                        dialog.dismiss();
                    }
                });
            }
        });

        finish.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                timer.cancel();
                Intent intent = new Intent(getApplicationContext(),Challenge_complete.class);
                startActivity(intent);
            }
        });
    }
    public void showdialog(){
        dialog.show();
        Button yes=dialog.findViewById(R.id.yes);
        Button no=dialog.findViewById(R.id.no);
        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timer.cancel();
                Intent intent = new Intent(getApplicationContext(),Lycle_list.class);
                startActivity(intent);
            }
        });
        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }

}