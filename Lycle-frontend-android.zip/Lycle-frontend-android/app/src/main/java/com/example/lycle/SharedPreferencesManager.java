package com.example.lycle;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPreferencesManager {
    public static final String PREFERENCES_NAME = "rebuild_preference";
    private static final boolean FIRST_APP_BOOLEAN = true;
    private static final Integer WHAT_EXER = 0;


    private static SharedPreferences getPreferences(Context context) {
        return context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);
    }


    public static boolean get_first_app_execute(Context context, String key) {
        SharedPreferences prefs = getPreferences(context);
        boolean value = prefs.getBoolean(key, FIRST_APP_BOOLEAN);
        return value;
    }
    
    public static void set_first_app_execute(Context context, String key, boolean value) {
        SharedPreferences prefs = getPreferences(context);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(key, value);
        editor.commit();
    }
    public static int get_WHAT_EXER_CHOICE(Context context, String key) {
        SharedPreferences prefs = getPreferences(context);
        int value = prefs.getInt(key, WHAT_EXER);
        return value;
    }

    public static void set_WHAT_EXER_CHOICE(Context context, String key, int value) {
        SharedPreferences prefs = getPreferences(context);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(key, value);
        editor.commit();
    }
}

