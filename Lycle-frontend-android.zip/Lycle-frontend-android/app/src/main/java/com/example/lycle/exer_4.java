package com.example.lycle;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class exer_4 extends AppCompatActivity {
    private ProgressBar progressBarCircle;
    int second=10;
    private TextView text,text1,text2;
    ImageView img;
    int c=0;
    Dialog dialog;
    Timer timer = new Timer();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exer_4);
        String[] a1 = new String[]{"손목 관절 운동", "손등 운동", "손바닥 운동", "손가락 운동", "손가락 및 손목 정리운동"};
        String[] a2 = new String[]{"손목 관절 및 손목 누르기", "손목 관절 좌우 스트레칭", "손목 스트레칭", "손목 스트레칭", "손등 누르기","손등 스트레칭", "손등 스트레칭", "손등 문지르기", "손바닥 누르기", "손바닥 두드리기"
                , "손가락으로 손바닥 두드리기", "손바닥 비비기", "손가락 스트레칭", "손가락 눌러주기", "손가락 잡아 당기기 운동", "손가락 끝의 운동", "손가락 및 손목 정리운동"};
        String[] a3 = new String[]{"손바닥 쪽의 앞팔  1/2지점에서 손목까지 3초씩 3회를 눌러줍니다. 이 동작은 혈액순환에 효과적입니다.", "10초씩 번갈아 3회씩 진행해주세요.", "두 손을 모아 엄지손가락 쪽으로 10초씩 3회 진행해주세요.", "두 손을 모아 새끼손가락 쪽으로 10초씩 3회 진행해주세요.", "그림에 나온 부분을 1회 3초씩 눌러주세요",
        "엄지손가락과 검지손가락 사이를 아프지 않게 눌러주세요","양옆으로 스트레칭을 10초씩 3회 진행해주세요.","왼쪽 손등으로 다른쪽 손등을 20회 문지릅니다. (반대쪽도 20회 시행)","새끼손가락 쪽에서 부터 엄지손가락 쪽으로 3초씩 3회\n" +
                "가운데 손가락을 중심으로 다섯 손가락을 10초씩 3회","양 손을 큰 소리가 나도록 박수쳐주세요. (20회 진행)","왼쪽 손바닥을 펴서 다른쪽 손가락으로 두드립니다. (50회)","양 손바닥에 열이 나도록 빠르게 비벼줍니다.","손바닥이 닿지 않게 손가락을 시원하게 당겨줍니다. (10회 진행)","그림에 표시된 부분을 확인하고 3초씩 지그시 눌러주세요.","한 손가락씩 5초간 시원하게 당겨주세요 ","좌우 손가락을 어깨 폭 보다 조금 넓게 3회 맞닿아주세요.\n" +
                "세게 부딪히는 느낌이 아닌 살포시 정확하게 닿는 모습이 되도록 유의해주세요.","손바닥이 지면을 향하도록 손끝을 위로 젖히고 양팔을 곧게 편 상태에서 좌우로 가볍게 흔들어 줍니다."};
        int[] a4=new int[]{R.drawable.hand_1,R.drawable.hand_2,R.drawable.hand_3,R.drawable.hand_4,R.drawable.hand_5,R.drawable.hand_6,R.drawable.hand_7,R.drawable.hand_8,R.drawable.hand_9,R.drawable.hand_10,R.drawable.hand_11,R.drawable.hand_12,R.drawable.hand_13,R.drawable.hand_14,R.drawable.hand_15,R.drawable.hand_16,R.drawable.hand_17};
        progressBarCircle = findViewById(R.id.progressBarCircle);
        text=findViewById(R.id.text);
        text1=findViewById(R.id.text1);
        text2=findViewById(R.id.text2);
        img=findViewById(R.id.img);

        ImageButton back=findViewById(R.id.back);
        dialog=new Dialog(exer_4.this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.alertdialog);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showdialog();
            }
        });
        final Handler handler = new Handler(){
            public void handleMessage(Message msg){
                // 원래 하려던 동작 (UI변경 작업 등)
                progressBarCircle.setProgress(second*10);
                text.setText(a1[c/4]);
                text1.setText(a2[c]);
                text2.setText(a3[c]);
                img.setImageResource(a4[c]);
            }
        };

        TimerTask timerTask = new TimerTask() {
            @Override
            public void run() {
                Message msg = handler.obtainMessage();
                handler.sendMessage(msg);

                if(second != 0) {
                    //1초씩 감소

                    second--;
                }
                if(second==0) {
                    second=10;
                    c++;
                }
                if(c==17){
                    timer.cancel();
                    Intent intent = new Intent(getApplicationContext(), Challenge_complete.class);
                    startActivity(intent);
                }
            }
        };
        //타이머를 실행
        timer.schedule(timerTask, 0, 1000); //Timer 실행

    }
    public void showdialog(){
        dialog.show();
        Button yes=dialog.findViewById(R.id.yes);
        Button no=dialog.findViewById(R.id.no);
        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timer.cancel();
                Intent intent = new Intent(getApplicationContext(),Lycle_list.class);
                startActivity(intent);
            }
        });
        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }
}