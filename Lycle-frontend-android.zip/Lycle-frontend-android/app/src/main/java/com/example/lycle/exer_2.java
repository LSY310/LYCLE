package com.example.lycle;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;

public class exer_2 extends AppCompatActivity {
    int t1=476;
    int t2=647;
    int t3=649;
    int t4=531;
    int t5=233;
    int t6=529;
    int all=0;
    DBHelper dbHelper;
    Dialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exer_2);
        Button start=findViewById(R.id.start);

        dialog=new Dialog(exer_2.this);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.alertdialog);
        ImageButton back=findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showdialog();
            }
        });

        dbHelper = new DBHelper(exer_2.this, 1);

        CheckBox c1=findViewById(R.id.st1);
        CheckBox c2=findViewById(R.id.st2);
        CheckBox c3=findViewById(R.id.st3);
        CheckBox c4=findViewById(R.id.st4);
        CheckBox c5=findViewById(R.id.st5);
        CheckBox c6=findViewById(R.id.st6);

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(c1.isChecked()==true){
                    all+=t1;
                }
                if(c2.isChecked()==true){
                    all+=t2;
                }
                if(c3.isChecked()==true){
                    all+=t3;
                }
                if(c4.isChecked()==true){
                    all+=t4;
                }
                if(c5.isChecked()==true){
                    all+=t5;
                }
                if(c6.isChecked()==true){
                    all+=t6;
                }
                if(all>=1800){
                    dbHelper.Delete();
                    if(c1.isChecked()==true){
                        dbHelper.insert("BfT37Ym-bBY");
                    }
                    if(c2.isChecked()==true){
                        dbHelper.insert("JcbjQy3x1bE");
                    }
                    if(c3.isChecked()==true){
                        dbHelper.insert("VFOe2aptGfA");
                    }
                    if(c4.isChecked()==true){
                        dbHelper.insert("xsjfsB2jxvU");
                    }
                    if(c5.isChecked()==true){
                        dbHelper.insert("Qrn9a9Kepyc");
                    }
                    if(c6.isChecked()==true){
                        dbHelper.insert("0Sa1gVuO324");
                    }
                    Intent intent = new Intent(getApplicationContext(),exer_2_2.class);
                    startActivity(intent);
                }
                else{
                    all=0;
                    AlertDialog.Builder ad=new AlertDialog.Builder(exer_2.this);
                    ad.setMessage("30분 이상의 운동 강의를 선택해주세요");
                    ad.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    ad.show();

                }



            }
        });
    }
    public void showdialog(){
        dialog.show();
        Button yes=dialog.findViewById(R.id.yes);
        Button no=dialog.findViewById(R.id.no);
        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Lycle_list.class);
                startActivity(intent);
            }
        });
        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }
}